# app.py

from flask import Flask, render_template, request, redirect, url_for
import mysql.connector

app = Flask(__name__)

# Connect to MySQL database
db = mysql.connector.connect(
    host="localhost",
    user="root",
    password="Cdac@2022",
    database="voter_system"
)

cursor = db.cursor()

# Create a new voter
@app.route('/add_voter', methods=['GET', 'POST'])
def add_voter():
    if request.method == 'POST':
        name = request.form['name']
        age = request.form['age']
        address = request.form['address']

        cursor.execute("INSERT INTO voters (name, age, address) VALUES (%s, %s, %s)", (name, age, address))
        db.commit()

        return redirect(url_for('list_voters'))

    return render_template('add_voter.html')

# View list of voters
@app.route('/list_voters')
def list_voters():
    cursor.execute("SELECT * FROM voters")
    voters = cursor.fetchall()
    return render_template('list_voters.html', voters=voters)

# View details of a voter
@app.route('/voter/<int:voter_id>')
def view_voter(voter_id):
    cursor.execute("SELECT * FROM voters WHERE id = %s", (voter_id,))
    voter = cursor.fetchone()
    return render_template('view_voter.html', voter=voter)

# Update voter details
@app.route('/update_voter/<int:voter_id>', methods=['GET', 'POST'])
def update_voter(voter_id):
    if request.method == 'POST':
        name = request.form['name']
        age = request.form['age']
        address = request.form['address']

        cursor.execute("UPDATE voters SET name = %s, age = %s, address = %s WHERE id = %s", (name, age, address, voter_id))
        db.commit()

        return redirect(url_for('list_voters'))
    
    cursor.execute("SELECT * FROM voters WHERE id = %s", (voter_id,))
    voter = cursor.fetchone()
    return render_template('update_voter.html', voter=voter)

# Delete a voter
@app.route('/delete_voter/<int:voter_id>')
def delete_voter(voter_id):
    cursor.execute("DELETE FROM voters WHERE id = %s", (voter_id,))
    db.commit()
    return redirect(url_for('list_voters'))

if __name__ == '__main__':
    app.run(debug=True)
